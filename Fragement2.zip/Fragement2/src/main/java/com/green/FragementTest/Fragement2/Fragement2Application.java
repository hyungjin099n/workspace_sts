package com.green.FragementTest.Fragement2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fragement2Application {

	public static void main(String[] args) {
		SpringApplication.run(Fragement2Application.class, args);
	}

}
